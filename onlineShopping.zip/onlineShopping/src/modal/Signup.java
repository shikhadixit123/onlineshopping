package modal;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class registration
 */
@WebServlet("/signup")
public class Signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
   {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("userName");
		String contactno=request.getParameter("contactNo");
		String email=request.getParameter("emailid");
		String address=request.getParameter("address");
		String password=request.getParameter("pass");
	   try {
		  Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
	Connection con = DriverManager.getConnection("jdbc:sqlserver://DESKTOP-GJ9L1KU(DESKTOP-GJ9L1KU/Shikha);databaseName=bookstore;user=DESKTOP-GJ9L1KU/Shikha;password=shikha@12");
	
		PreparedStatement ps=con.prepareStatement("Insert into userdetails values(?,?,?,?,?)");
	    
	    ps.setString(1,name);
	    ps.setString(2,contactno);
	    ps.setString(3,email);
	    ps.setString(4,address);
	    ps.setString(5,password);
	    
	    int i=ps.executeUpdate();
	    if(i>0)
	    {
	    out.print("You are successfully registered...");	
	    }
	}
	   catch(Exception e)
	   {
		  out.print(e);
	   }
   }
}
		   
	  
	


